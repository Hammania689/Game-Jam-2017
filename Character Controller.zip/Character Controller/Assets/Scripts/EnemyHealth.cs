using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyHealth : MonoBehaviour, IDamageable
{
    #region Global Variable Declaration

    public float startingHealth = 10f;
    public float currentHealth = 0f;
    public Slider healthSlider;

    Transform myTransform;
    Animator anim;

    #endregion

    void Awake () 
	{
        myTransform = transform;
        anim = GetComponent<Animator>();
	}
    void Start()
    {
        currentHealth = startingHealth;
    }
    void Update () 
	{
        if (currentHealth <= 0)
        {
            Death();
            return;
        }
    }

    public void TakeDamage(float damage)
    {
        if (currentHealth <= 0)
        {
            Death();
            return;
        }
        currentHealth -= damage;
    }
    public void TakeDamage(float damage, Vector3 pos)
    {
        if (currentHealth <= 0)
        {
            Death();
            return;
        }
        currentHealth -= damage;
    }
    void Death()
    {
        currentHealth = 0;
        if (healthSlider != null)
        {
            healthSlider.value = 0;
        }

        if (anim != null)
        {
            anim.SetBool("Death", true);
        }
        myTransform.position = new Vector3(0f, 3000f, 0f);
        this.gameObject.SetActive(false);

        return;
    }
    void Respawn()
    {
        this.gameObject.SetActive(true);
        currentHealth = startingHealth;
        healthSlider.value = currentHealth;
    }
}
