﻿using UnityEngine;
using System.Collections;

public class FrontFacingBillboard : MonoBehaviour 
{
	public Camera m_Camera;

	void start()
	{
//		m_Camera = Camera.main;
	}
	void Update () 
	{

		m_Camera = GameMasterObject.camInUse;
		
		if (m_Camera != null) 
		{
			transform.LookAt (transform.position + m_Camera.transform.rotation * Vector3.forward, m_Camera.transform.rotation * Vector3.up);
		}
	}
}
