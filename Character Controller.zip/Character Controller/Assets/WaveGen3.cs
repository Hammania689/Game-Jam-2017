﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveGen3 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.Translate(.5f, 0, 0);
        if (transform.position.x >= -15)
            transform.localScale += new Vector3(0, -.5f, 0);
        else if (transform.localScale.y < 2f)
            transform.localScale += new Vector3(0, .25f, 0);
        if (transform.position.x >= -14f)
        {
            transform.Translate(-46f, 0, 0);
        }
    }
}
