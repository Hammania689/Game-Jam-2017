﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveGen2 : MonoBehaviour
{

    // Use this for initialization

    void Start()
    {

    }



    // Update is called once per frame
    void Update()
    {
        transform.Translate(-.25f, 0, 0);
        if (transform.position.x <= 14)
            transform.localScale += new Vector3(0, -0.5f, 0);
        else if (transform.localScale.y < 2.5f)
            transform.localScale += new Vector3(0, 0.5f, 0);
        if (transform.position.x <= 13f)
        {
            transform.Translate(15f, 0, 0);
        }
    }
}